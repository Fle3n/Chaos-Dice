// Подключение к Socket.IO
const socket = io();

// Состояние приложения
let selectedDiceType = 'd6';
let diceCount = 1;

// ===== ЗВУКОВАЯ СИСТЕМА =====
class SoundManager {
    constructor() {
        this.audioContext = null;
        this.enabled = true;
        this.volume = 0.3;
    }
    
    init() {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
    }
    
    // Звук клика по кнопке
    playClick() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(800, this.audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(600, this.audioContext.currentTime + 0.05);
        
        gainNode.gain.setValueAtTime(this.volume * 0.3, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.05);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.05);
    }
    
    // Звук броска кубика (начало)
    playRollStart() {
        if (!this.enabled) return;
        this.init();
        
        // Создаём шум "тряски"
        const duration = 0.15;
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'triangle';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime);
        oscillator.frequency.linearRampToValueAtTime(100, this.audioContext.currentTime + duration);
        
        gainNode.gain.setValueAtTime(this.volume * 0.2, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + duration);
    }
    
    // Звук приземления кубика
    playDiceLand() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(300, this.audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(150, this.audioContext.currentTime + 0.1);
        
        gainNode.gain.setValueAtTime(this.volume * 0.4, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.1);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.1);
    }
    
    // Звук успеха/победы
    playSuccess() {
        if (!this.enabled) return;
        this.init();
        
        const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
        
        notes.forEach((freq, i) => {
            setTimeout(() => {
                const oscillator = this.audioContext.createOscillator();
                const gainNode = this.audioContext.createGain();
                
                oscillator.type = 'sine';
                oscillator.connect(gainNode);
                gainNode.connect(this.audioContext.destination);
                
                oscillator.frequency.setValueAtTime(freq, this.audioContext.currentTime);
                
                gainNode.gain.setValueAtTime(this.volume * 0.3, this.audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.2);
                
                oscillator.start(this.audioContext.currentTime);
                oscillator.stop(this.audioContext.currentTime + 0.2);
            }, i * 100);
        });
    }
    
    // Звук hover
    playHover() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(1200, this.audioContext.currentTime);
        
        gainNode.gain.setValueAtTime(this.volume * 0.1, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.03);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.03);
    }
    
    // Звук отправки сообщения
    playSend() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(600, this.audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(900, this.audioContext.currentTime + 0.08);
        
        gainNode.gain.setValueAtTime(this.volume * 0.2, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.08);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.08);
    }
}

const soundManager = new SoundManager();

// Инициализация
document.addEventListener('DOMContentLoaded', () => {
    console.log('Инициализация главной страницы...');
    initializeSocket();
    initializeSoundEffects();

    initializeDiceControls();
    initializeChatControls();
    initializeMultiplayerControls();
    loadRooms();
});

// ===== ЗВУКОВЫЕ ЭФФЕКТЫ ДЛЯ КНОПОК =====
function initializeSoundEffects() {
    // Звук для всех кнопок при клике
    document.querySelectorAll('button, .btn-primary, .btn-secondary, .btn-roll').forEach(btn => {
        btn.addEventListener('click', () => soundManager.playClick());
    });
    
    // Звук hover для кнопок выбора кубика
    document.querySelectorAll('button, .btn-primary, .btn-secondary, .btn-roll, .dice-type-btn').forEach(btn => {
        btn.addEventListener('mouseenter', () => soundManager.playHover());
    });
}

// ===== SOCKET.IO =====
function initializeSocket() {
    socket.on('connect', () => {
        console.log('Подключено к серверу');
        socket.emit('set_user', { username: currentUsername });
        socket.emit('get_chat_history');
    });

    socket.on('disconnect', () => {
        console.log('Отключено от сервера');
    });

    socket.on('chat_history', (messages) => {
        const chatContainer = document.getElementById('global-chat-messages');
        chatContainer.innerHTML = '';
        messages.forEach(msg => addChatMessage(msg, 'global'));
        chatContainer.scrollTop = chatContainer.scrollHeight;
    });

    socket.on('new_global_message', (message) => {
        addChatMessage(message, 'global');
    });

    socket.on('solo_roll_result', (data) => {
        displayRollResult(data);
    });

    socket.on('room_created', (data) => {
        console.log('Комната создана:', data);
        window.location.href = `/room/${data.room_code}`;
    });

    socket.on('join_error', (data) => {
        alert(data.error);
    });

    socket.on('joined_room', (data) => {
        console.log('Присоединились к комнате:', data.room_code);
        window.location.href = `/room/${data.room_code}`;
    });
}

// ===== УПРАВЛЕНИЕ КУБИКАМИ =====
function initializeDiceControls() {
    document.querySelectorAll('.dice-type-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.dice-type-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedDiceType = btn.dataset.dice;
            
            const customGroup = document.getElementById('custom-dice-group');
            if (selectedDiceType === 'custom') {
                customGroup.style.display = 'block';
                document.getElementById('custom-dice-value').focus();
            } else {
                customGroup.style.display = 'none';
            }
        });
    });

    const customInput = document.getElementById('custom-dice-value');
    if (customInput) {
        customInput.addEventListener('input', () => {
            let value = parseInt(customInput.value);
            if (value < 2) customInput.value = 2;
            if (value > 1000) customInput.value = 1000;
        });
        
        customInput.addEventListener('blur', () => {
            let value = parseInt(customInput.value);
            if (isNaN(value) || value < 2) customInput.value = 2;
            if (value > 1000) customInput.value = 1000;
        });
    }

    document.getElementById('dice-count-minus').addEventListener('click', () => {
        if (diceCount > 1) {
            diceCount--;
            document.getElementById('dice-count-display').textContent = diceCount;
        }
    });

    document.getElementById('dice-count-plus').addEventListener('click', () => {
        if (diceCount < 10) {
            diceCount++;
            document.getElementById('dice-count-display').textContent = diceCount;
        }
    });

    document.getElementById('roll-dice-btn').addEventListener('click', rollDice);
}

function rollDice() {
    const display = document.getElementById('dice-display');
    const resultDiv = document.getElementById('roll-result');
    const rollBtn = document.getElementById('roll-dice-btn');
    
    let diceType = selectedDiceType;
    if (diceType === 'custom') {
        let customValue = parseInt(document.getElementById('custom-dice-value').value);
        if (isNaN(customValue) || customValue < 2) customValue = 2;
        if (customValue > 1000) customValue = 1000;
        document.getElementById('custom-dice-value').value = customValue;
        diceType = `d${customValue}`;
    }

    // Звук начала броска
    soundManager.playRollStart();
    
    rollBtn.disabled = true;
    resultDiv.textContent = '';
    display.innerHTML = '';
    
    // Создаём анимированные кубики
    for (let i = 0; i < diceCount; i++) {
        const dice = document.createElement('div');
        dice.className = 'dice rolling';
        dice.innerHTML = `
            <div class="dice-face">
                <span class="dice-dots"></span>
            </div>
        `;
        display.appendChild(dice);
        
        // Добавляем случайную задержку для каждого кубика
        dice.style.animationDelay = `${i * 0.1}s`;
    }

    socket.emit('solo_roll', {
        dice_type: diceType,
        dice_count: diceCount
    });
}

function displayRollResult(data) {
    const display = document.getElementById('dice-display');
    const resultDiv = document.getElementById('roll-result');
    const rollBtn = document.getElementById('roll-dice-btn');
    
    // Задержка перед показом результата (время анимации)
    setTimeout(() => {
        display.innerHTML = '';
        
        data.rolls.forEach((roll, index) => {
            setTimeout(() => {
                // Звук приземления кубика
                soundManager.playDiceLand();
                
                const dice = document.createElement('div');
                dice.className = 'dice result';
                dice.innerHTML = `<span class="dice-value">${roll}</span>`;
                
                // Определяем максимальное значение для подсветки
                const maxValue = parseInt(selectedDiceType === 'custom' 
                    ? document.getElementById('custom-dice-value').value 
                    : selectedDiceType.replace('d', ''));
                
                if (roll === maxValue) {
                    dice.classList.add('max-roll');
                } else if (roll === 1) {
                    dice.classList.add('min-roll');
                }
                
                display.appendChild(dice);
            }, index * 200);
        });

        // Показываем результат после всех кубиков
        setTimeout(() => {
            resultDiv.innerHTML = `<span class="result-label">Сумма:</span> <span class="result-value">${data.total}</span>`;
            resultDiv.classList.add('show');
            rollBtn.disabled = false;
            
            // Звук успеха
            soundManager.playSuccess();
            
            let diceLabel = selectedDiceType;
            if (selectedDiceType === 'custom') {
                diceLabel = `d${document.getElementById('custom-dice-value').value}`;
            }
            addToHistory(diceLabel, diceCount, data.rolls, data.total);
        }, data.rolls.length * 200 + 100);
        
    }, 800);
}

function addToHistory(diceType, count, rolls, total) {
    const historyList = document.getElementById('roll-history-list');
    const historyItem = document.createElement('div');
    historyItem.className = 'history-item new';
    historyItem.innerHTML = `
        <span class="history-dice">${count}x ${diceType.toUpperCase()}</span>
        <span class="history-rolls">[${rolls.join(', ')}]</span>
        <span class="history-result">= ${total}</span>
    `;
    historyList.insertBefore(historyItem, historyList.firstChild);
    
    // Убираем класс new после анимации
    setTimeout(() => historyItem.classList.remove('new'), 500);
    
    if (historyList.children.length > 10) {
        historyList.removeChild(historyList.lastChild);
    }
}

// ===== ГЛОБАЛЬНЫЙ ЧАТ =====
function initializeChatControls() {
    const chatInput = document.getElementById('global-chat-input');
    const sendBtn = document.getElementById('send-global-msg');

    sendBtn.addEventListener('click', sendGlobalMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendGlobalMessage();
    });
}

function sendGlobalMessage() {
    const input = document.getElementById('global-chat-input');
    const text = input.value.trim();
    
    if (text) {
        soundManager.playSend();
        socket.emit('global_chat_message', {
            username: currentUsername,
            text: text.substring(0, 200)
        });
        input.value = '';
    }
}

function addChatMessage(message, type) {
    const container = document.getElementById(`${type}-chat-messages`);
    if (!container) return;
    
    const msgDiv = document.createElement('div');
    msgDiv.className = 'chat-message new';
    msgDiv.innerHTML = `
        <span class="username">${escapeHtml(message.username)}</span>
        <span class="timestamp">${message.timestamp}</span>
        <div class="text">${escapeHtml(message.text)}</div>
    `;
    container.appendChild(msgDiv);
    container.scrollTop = container.scrollHeight;
    
    setTimeout(() => msgDiv.classList.remove('new'), 300);
}

// ===== МУЛЬТИПЛЕЕР =====
function initializeMultiplayerControls() {
    const privateCheckbox = document.getElementById('room-private');
    if (privateCheckbox) {
        privateCheckbox.addEventListener('change', (e) => {
            document.getElementById('password-group').style.display = 
                e.target.checked ? 'block' : 'none';
        });
    }

    const createRoomBtn = document.getElementById('create-room-btn');
    if (createRoomBtn) {
        createRoomBtn.addEventListener('click', createRoom);
    }

    const joinRoomBtn = document.getElementById('join-room-btn');
    if (joinRoomBtn) {
        joinRoomBtn.addEventListener('click', () => {
            const code = document.getElementById('join-room-code').value.trim().toUpperCase();
            if (code) {
                joinRoom(code);
            } else {
                alert('Введите код комнаты');
            }
        });
    }

    const joinRoomCode = document.getElementById('join-room-code');
    if (joinRoomCode) {
        joinRoomCode.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const code = joinRoomCode.value.trim().toUpperCase();
                if (code) joinRoom(code);
            }
        });
    }

    const refreshBtn = document.getElementById('refresh-rooms-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadRooms);
    }
}

function createRoom() {
    const nameInput = document.getElementById('room-name');
    const privateCheckbox = document.getElementById('room-private');
    const passwordInput = document.getElementById('room-password');
    
    const name = nameInput ? nameInput.value.trim().substring(0, 20) : '';
    const roomName = name || 'Комната ' + Math.floor(Math.random() * 1000);
    const isPrivate = privateCheckbox ? privateCheckbox.checked : false;
    const password = passwordInput ? passwordInput.value : '';

    if (isPrivate && !password) {
        alert('Для приватной комнаты необходимо указать пароль');
        return;
    }

    socket.emit('create_room', {
        name: roomName,
        is_private: isPrivate,
        password: password,
        username: currentUsername
    });
}

function joinRoom(code) {
    window.location.href = `/room/${code}`;
}

function loadRooms() {
    fetch('/get_rooms')
        .then(res => res.json())
        .then(rooms => {
            const roomsList = document.getElementById('rooms-list');
            if (!roomsList) return;
            
            if (rooms.length === 0) {
                roomsList.innerHTML = '<div class="no-rooms">Нет доступных комнат</div>';
                return;
            }
            
            roomsList.innerHTML = rooms.map(room => `
                <div class="room-item" onclick="joinRoom('${room.code}')">
                    <div class="room-item-header">
                        <span class="room-item-name">${escapeHtml(room.name)}</span>
                        <span class="room-item-players">${room.players}/${room.max_players}</span>
                    </div>
                    <div class="room-item-info">
                        Владелец: ${escapeHtml(room.owner)} | Код: ${room.code}
                    </div>
                </div>
            `).join('');
        })
        .catch(err => console.error('Ошибка загрузки комнат:', err));
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

window.joinRoom = joinRoom;
window.soundManager = soundManager;