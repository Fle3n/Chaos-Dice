// Подключение к Socket.IO
const socket = io();

// Состояние игры
let gameState = {
    isMyTurn: false,
    isRolling: false,
    currentPlayer: null,
    currentRound: 0,
    players: [],
    diceType: 'd6',
    diceCount: 1,
    roundResults: {},
    timerInterval: null,
    timerSeconds: 7,
    hasRolled: false,
    isCustomDice: false,
    customDiceValue: 12
};

// Инициализация
document.addEventListener('DOMContentLoaded', () => {
    console.log('Инициализация комнаты...');
    initializeSocket();
    initializeRoomControls();
    initializeChat();
    initializeDiceSelector();
    initializeSoundEffects();
    updateOwnerUI();
});

// ===== ЗВУКОВЫЕ ЭФФЕКТЫ ДЛЯ КНОПОК =====
function initializeSoundEffects() {
    // Звук для всех кнопок при клике
    document.querySelectorAll('button, .btn-primary, .btn-secondary, .btn-roll').forEach(btn => {
        btn.addEventListener('click', () => soundManager.playClick());
    });
    
    // Звук hover для кнопок выбора кубика
    document.querySelectorAll('button, .btn-primary, .btn-secondary, .btn-roll, .dice-type-btn').forEach(btn => {
        btn.addEventListener('mouseenter', () => soundManager.playHover());
    });
}

function updateOwnerUI() {
    const settingsPanel = document.getElementById('game-settings');
    
    if (isOwner) {
        settingsPanel.style.display = 'block';
        settingsPanel.classList.add('owner-view');
    } else {
        settingsPanel.style.display = 'block';
        settingsPanel.classList.add('viewer-view');
        document.querySelectorAll('.dice-option, .count-btn-room, #custom-dice-value').forEach(btn => {
            btn.disabled = true;
        });
        document.getElementById('start-game-btn').style.display = 'none';
    }
}

// ===== СЕЛЕКТОР КУБИКОВ =====
function initializeDiceSelector() {
    // Выбор типа кубика
    document.querySelectorAll('#room-dice-selector .dice-option').forEach(btn => {
        btn.addEventListener('click', () => {
            if (!isOwner) return;
            
            document.querySelectorAll('#room-dice-selector .dice-option').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const value = btn.dataset.value;
            const customContainer = document.getElementById('custom-dice-container');
            
            if (value === 'custom') {
                customContainer.style.display = 'block';
                gameState.isCustomDice = true;
                document.getElementById('custom-dice-value').focus();
                // Не отправляем настройки пока не введено значение
            } else {
                customContainer.style.display = 'none';
                gameState.isCustomDice = false;
                document.getElementById('game-dice-type').value = value;
                gameState.diceType = value;
                updateSettings();
            }
        });
    });
    
    // Валидация и отправка кастомного значения
    const customInput = document.getElementById('custom-dice-value');
    if (customInput) {
        customInput.addEventListener('input', () => {
            if (!isOwner) return;
            
            let value = parseInt(customInput.value);
            if (value < 2) customInput.value = 2;
            if (value > 1000) customInput.value = 1000;
        });
        
        customInput.addEventListener('change', () => {
            if (!isOwner || !gameState.isCustomDice) return;
            
            let value = parseInt(customInput.value);
            if (isNaN(value) || value < 2) value = 2;
            if (value > 1000) value = 1000;
            
            customInput.value = value;
            gameState.customDiceValue = value;
            gameState.diceType = `d${value}`;
            document.getElementById('game-dice-type').value = `d${value}`;
            updateSettings();
        });
        
        customInput.addEventListener('blur', () => {
            if (!isOwner || !gameState.isCustomDice) return;
            
            let value = parseInt(customInput.value);
            if (isNaN(value) || value < 2) value = 2;
            if (value > 1000) value = 1000;
            
            customInput.value = value;
            gameState.customDiceValue = value;
            gameState.diceType = `d${value}`;
            document.getElementById('game-dice-type').value = `d${value}`;
            updateSettings();
        });
    }
    
    // Уменьшение количества
    document.getElementById('dice-count-dec').addEventListener('click', () => {
        if (!isOwner) return;
        
        let count = parseInt(document.getElementById('game-dice-count').value);
        if (count > 1) {
            count--;
            document.getElementById('game-dice-count').value = count;
            document.getElementById('dice-count-value').textContent = count;
            gameState.diceCount = count;
            updateSettings();
        }
    });
    
    // Увеличение количества
    document.getElementById('dice-count-inc').addEventListener('click', () => {
        if (!isOwner) return;
        
        let count = parseInt(document.getElementById('game-dice-count').value);
        if (count < 5) {
            count++;
            document.getElementById('game-dice-count').value = count;
            document.getElementById('dice-count-value').textContent = count;
            gameState.diceCount = count;
            updateSettings();
        }
    });
}

// ===== SOCKET.IO =====
function initializeSocket() {
    socket.on('connect', () => {
        console.log('Подключено к серверу комнаты');
        updateConnectionStatus(true);
        
        socket.emit('join_room', {
            room_code: roomCode,
            username: currentUsername
        });
    });

    socket.on('disconnect', () => {
        console.log('Отключено от сервера');
        updateConnectionStatus(false);
    });

    socket.on('joined_room', (data) => {
        console.log('Присоединились к комнате:', data);
        gameState.players = data.room_data.players;
        
        isOwner = data.is_owner;
        updateOwnerUI();
        
        updatePlayersList(data.room_data.players);
        createPlayersGameArea(data.room_data.players);
        updateLeaderboard(data.room_data.players);
        
        if (data.room_data.game_state) {
            gameState.diceType = data.room_data.game_state.dice_type;
            gameState.diceCount = data.room_data.game_state.dice_count;
            gameState.currentRound = data.room_data.game_state.round || 0;
            updateGameSettingsUI(data.room_data.game_state);
            document.getElementById('current-round').textContent = gameState.currentRound;
        }
        
        updateRollButtonState();
    });

    socket.on('player_joined', (data) => {
        gameState.players = data.players;
        updatePlayersList(data.players);
        createPlayersGameArea(data.players);
        updateLeaderboard(data.players);
        addSystemMessage(`🎮 ${data.username} присоединился к игре`);
        showNotification(`${data.username} присоединился`, 'info');
    });

    socket.on('player_left', (data) => {
        gameState.players = data.players;
        updatePlayersList(data.players);
        createPlayersGameArea(data.players);
        updateLeaderboard(data.players);
        addSystemMessage(`👋 ${data.username} покинул игру`);
    });

    socket.on('new_owner', (data) => {
        isOwner = (data.owner === currentUsername);
        updateOwnerUI();
        
        if (isOwner) {
            addSystemMessage('👑 Вы стали владельцем комнаты!');
            showNotification('Вы теперь владелец комнаты!', 'success');
            document.querySelectorAll('.dice-option, .count-btn-room, #custom-dice-value').forEach(btn => {
                btn.disabled = false;
            });
            document.getElementById('start-game-btn').style.display = 'inline-block';
        } else {
            addSystemMessage(`👑 ${data.owner} стал владельцем комнаты`);
        }
    });

    socket.on('settings_updated', (data) => {
        gameState.diceType = data.dice_type;
        gameState.diceCount = data.dice_count;
        updateGameSettingsUI({dice_type: data.dice_type, dice_count: data.dice_count});
        addSystemMessage(`⚙️ Настройки: ${data.dice_count}x ${data.dice_type.toUpperCase()}`);
    });

    socket.on('roll_started', (data) => {
        gameState.isRolling = true;
        gameState.currentPlayer = data.current_player;
        gameState.currentRound = data.round;
        gameState.roundResults = {};
        gameState.diceType = data.dice_type;
        gameState.diceCount = data.dice_count;
        gameState.hasRolled = false;
        
        document.getElementById('current-round').textContent = gameState.currentRound;
        
        resetAllPlayersDice();
        
        const isMyTurn = data.current_player === currentUsername;
        gameState.isMyTurn = isMyTurn;
        
        updateTurnInfo(data.current_player);
        updateRollButtonState();
        highlightCurrentPlayer(data.current_player);
        
        startTimer(data.timer_seconds || 7);
        
        document.getElementById('round-results').classList.remove('active');
        document.getElementById('start-game-btn').disabled = true;
        document.getElementById('next-round-btn').style.display = 'none';
        
        addSystemMessage(`🎲 Раунд ${gameState.currentRound} начался! Кубики: ${data.dice_count}x ${data.dice_type.toUpperCase()}`);
        
        if (isMyTurn) {
            showNotification('🎯 Ваш ход! Бросайте кубики!', 'info');
        }
    });

    socket.on('roll_result', (data) => {
        gameState.roundResults[data.username] = {
            rolls: data.rolls,
            total: data.total
        };
        
        if (data.username === currentUsername) {
            gameState.hasRolled = true;
            gameState.isMyTurn = false;
        }
        
        animatePlayerRoll(data.username, data.rolls, data.total);
        updatePlayerCurrentScore(data.username, data.total);
        
        const isMe = data.username === currentUsername;
        if (isMe) {
            addSystemMessage(`🎯 Вы выбросили: [${data.rolls.join(', ')}] = ${data.total}`);
        } else {
            addSystemMessage(`🎲 ${data.username} выбросил: [${data.rolls.join(', ')}] = ${data.total}`);
        }
        
        updateRollButtonState();
    });

    socket.on('auto_roll_executed', (data) => {
        const isMe = data.username === currentUsername;
        if (isMe) {
            gameState.hasRolled = true;
            gameState.isMyTurn = false;
            addSystemMessage(`⏰ Время вышло! Автоматический бросок: [${data.rolls.join(', ')}] = ${data.total}`);
            showNotification('⏰ Время вышло! Кубики брошены автоматически', 'warning');
            updateRollButtonState();
        } else {
            addSystemMessage(`⏰ ${data.username}: время вышло, автоматический бросок`);
        }
    });

    socket.on('next_turn', (data) => {
        gameState.currentPlayer = data.current_player;
        const isMyTurn = data.current_player === currentUsername;
        gameState.isMyTurn = isMyTurn && !gameState.hasRolled;
        
        updateTurnInfo(data.current_player);
        updateRollButtonState();
        highlightCurrentPlayer(data.current_player);
        
        startTimer(data.timer_seconds || 7);
        
        if (isMyTurn && !gameState.hasRolled) {
            showNotification('🎯 Ваш ход! Бросайте кубики!', 'info');
        }
    });

    socket.on('round_finished', (data) => {
        gameState.isRolling = false;
        gameState.isMyTurn = false;
        gameState.hasRolled = false;
        gameState.players = data.players;
        
        stopTimer();
        updateRollButtonState();
        showRoundResults(data);
        updateLeaderboard(data.players);
        updatePlayersList(data.players);
        addRoundToHistory(data);
        highlightWinner(data.winner);
        
        document.getElementById('start-game-btn').disabled = false;
        
        if (data.winner === currentUsername) {
            soundManager.playWin();
            showNotification('🏆 Вы победили в этом раунде!', 'success');
        }
        else {
            soundManager.playSuccess();
        }
        
        addSystemMessage(`🏆 Раунд завершён! Победитель: ${data.winner} (${data.winner_score})`);
    });

    socket.on('roll_error', (data) => {
        showNotification(data.error, 'error');
        const rollBtn = document.getElementById('roll-btn');
        rollBtn.disabled = false;
        rollBtn.classList.remove('rolling');
    });

    socket.on('new_room_message', (message) => {
        addChatMessage(message);
    });

    socket.on('join_error', (data) => {
        showNotification(data.error, 'error');
        setTimeout(() => window.location.href = '/', 2000);
    });
}

// ===== ТАЙМЕР =====
function startTimer(seconds) {
    stopTimer();
    
    gameState.timerSeconds = seconds;
    const timerContainer = document.getElementById('timer-container');
    const timerText = document.getElementById('timer-text');
    const timerProgress = document.getElementById('timer-progress');
    
    timerContainer.style.display = 'flex';
    timerText.textContent = seconds;
    timerText.classList.remove('warning');
    timerProgress.classList.remove('warning');
    
    const circumference = 2 * Math.PI * 45;
    timerProgress.style.strokeDasharray = circumference;
    timerProgress.style.strokeDashoffset = 0;
    
    let timeLeft = seconds;
    
    gameState.timerInterval = setInterval(() => {
        timeLeft--;
        timerText.textContent = Math.max(0, timeLeft);
        
        const progress = (seconds - timeLeft) / seconds;
        timerProgress.style.strokeDashoffset = circumference * progress;
        
        if (timeLeft <= 3 && timeLeft > 0) {
            soundManager.playWarning();
            timerProgress.classList.add('warning');
            timerText.classList.add('warning');
        }
        
        if (timeLeft <= 0) stopTimer();
    }, 1000);
}

function stopTimer() {
    if (gameState.timerInterval) {
        clearInterval(gameState.timerInterval);
        gameState.timerInterval = null;
    }
    
    const timerContainer = document.getElementById('timer-container');
    const timerProgress = document.getElementById('timer-progress');
    const timerText = document.getElementById('timer-text');
    
    if (timerContainer) timerContainer.style.display = 'none';
    if (timerProgress) timerProgress.classList.remove('warning');
    if (timerText) timerText.classList.remove('warning');
}

// ===== УПРАВЛЕНИЕ КОМНАТОЙ =====
function initializeRoomControls() {
    document.getElementById('leave-room-btn').addEventListener('click', () => {
        if (confirm('Вы уверены, что хотите покинуть комнату?')) {
            socket.emit('leave_room', { room_code: roomCode, username: currentUsername });
            window.location.href = '/';
        }
    });

    document.getElementById('start-game-btn').addEventListener('click', startRound);
    document.getElementById('roll-btn').addEventListener('click', rollDice);
    document.getElementById('next-round-btn').addEventListener('click', startRound);
}

function updateSettings() {
    if (!isOwner) return;
    
    let diceType = gameState.diceType;
    
    // Если выбран кастомный кубик
    if (gameState.isCustomDice) {
        const customValue = parseInt(document.getElementById('custom-dice-value').value) || 12;
        diceType = `d${customValue}`;
    }
    
    const diceCount = parseInt(document.getElementById('game-dice-count').value);
    
    socket.emit('update_game_settings', {
        room_code: roomCode,
        dice_type: diceType,
        dice_count: diceCount
    });
}

function startRound() {
    if (gameState.players.length < 2) {
        showNotification('Нужно минимум 2 игрока для начала игры', 'error');
        return;
    }
    
    socket.emit('start_roll', { room_code: roomCode, username: currentUsername });
}

function rollDice() {
    if (!gameState.isMyTurn || !gameState.isRolling || gameState.hasRolled) return;

    soundManager.playRollStart();

    const rollBtn = document.getElementById('roll-btn');
    rollBtn.disabled = true;
    rollBtn.classList.add('rolling');
    
    stopTimer();
    showRollingAnimation(currentUsername);
    
    socket.emit('player_roll', { room_code: roomCode, username: currentUsername });
    
    gameState.hasRolled = true;
    gameState.isMyTurn = false;
    updateRollButtonState();
}

function updateRollButtonState() {
    const rollBtn = document.getElementById('roll-btn');
    const rollHint = document.getElementById('roll-hint');
    
    const canRoll = gameState.isMyTurn && gameState.isRolling && !gameState.hasRolled;
    
    if (canRoll) {
        rollBtn.disabled = false;
        rollBtn.classList.remove('rolling');
        rollBtn.classList.add('active');
        rollHint.textContent = '🎯 Ваш ход! Нажмите чтобы бросить!';
        rollHint.classList.add('my-turn');
    } else if (gameState.isRolling && gameState.hasRolled) {
        rollBtn.disabled = true;
        rollBtn.classList.remove('active', 'rolling');
        rollHint.textContent = '✓ Вы уже бросили. Ожидание других игроков...';
        rollHint.classList.remove('my-turn');
    } else if (gameState.isRolling && !gameState.isMyTurn) {
        rollBtn.disabled = true;
        rollBtn.classList.remove('active', 'rolling');
        rollHint.textContent = `⏳ Ожидание хода: ${gameState.currentPlayer || '...'}`;
        rollHint.classList.remove('my-turn');
    } else {
        rollBtn.disabled = true;
        rollBtn.classList.remove('active', 'rolling');
        rollHint.textContent = 'Ожидание начала раунда...';
        rollHint.classList.remove('my-turn');
    }
}

// ===== ОТОБРАЖЕНИЕ =====
function createPlayersGameArea(players) {
    const area = document.getElementById('all-players-dice-area');
    
    if (players.length === 0) {
        area.innerHTML = `
            <div class="waiting-for-players">
                <div class="waiting-icon">🎲</div>
                <div class="waiting-text">Ожидание игроков...</div>
            </div>
        `;
        return;
    }
    
    area.innerHTML = players.map(player => `
        <div class="player-dice-section" id="player-dice-${player.username}" data-username="${player.username}">
            <div class="player-dice-header">
                <div class="player-dice-avatar ${player.username === currentUsername ? 'is-me' : ''}">
                    ${player.username.charAt(0).toUpperCase()}
                </div>
                <div class="player-dice-info">
                    <span class="player-dice-name">
                        ${escapeHtml(player.username)}
                        ${player.username === currentUsername ? ' (Вы)' : ''}
                        ${player.username === roomOwner ? ' 👑' : ''}
                    </span>
                    <span class="player-dice-status" id="status-${player.username}">Ожидание</span>
                </div>
                <div class="player-dice-score" id="score-${player.username}">
                    <span class="score-label">Очки:</span>
                    <span class="score-value">-</span>
                </div>
            </div>
            <div class="player-dice-display" id="dice-display-${player.username}">
                <div class="dice-placeholder">🎲</div>
            </div>
        </div>
    `).join('');
}

function resetAllPlayersDice() {
    gameState.players.forEach(player => {
        const display = document.getElementById(`dice-display-${player.username}`);
        const status = document.getElementById(`status-${player.username}`);
        const score = document.getElementById(`score-${player.username}`);
        
        if (display) {
            display.innerHTML = '<div class="dice-placeholder">🎲</div>';
            display.classList.remove('rolled', 'rolling');
        }
        if (status) {
            status.textContent = 'Ожидание';
            status.className = 'player-dice-status waiting';
        }
        if (score) score.querySelector('.score-value').textContent = '-';
        
        const section = document.getElementById(`player-dice-${player.username}`);
        if (section) section.classList.remove('winner', 'current-turn');
    });
}

function showRollingAnimation(username) {
    const display = document.getElementById(`dice-display-${username}`);
    const status = document.getElementById(`status-${username}`);
    
    if (display) {
        display.classList.add('rolling');
        display.innerHTML = '';
        for (let i = 0; i < gameState.diceCount; i++) {
            const dice = document.createElement('div');
            dice.className = 'dice rolling-dice';
            dice.textContent = '?';
            display.appendChild(dice);
        }
    }
    
    if (status) {
        status.textContent = 'Бросает...';
        status.className = 'player-dice-status rolling';
    }
}

function animatePlayerRoll(username, rolls, total) {
    const display = document.getElementById(`dice-display-${username}`);
    const status = document.getElementById(`status-${username}`);
    const score = document.getElementById(`score-${username}`);
    
    if (!display) return;
    
    display.classList.remove('rolling');
    display.classList.add('showing-result');
    display.innerHTML = '';
    
    rolls.forEach((roll, index) => {
        setTimeout(() => {
            soundManager.playDiceLand();
            const dice = document.createElement('div');
            dice.className = 'dice result-dice';
            dice.textContent = roll;
            
            const maxValue = parseInt(gameState.diceType.replace('d', ''));
            if (roll === maxValue) dice.classList.add('max-roll');
            else if (roll === 1) dice.classList.add('min-roll');
            
            display.appendChild(dice);
        }, index * 150);
    });
    
    setTimeout(() => {
        display.classList.remove('showing-result');
        display.classList.add('rolled');
        
        if (status) {
            status.textContent = 'Готово ✓';
            status.className = 'player-dice-status done';
        }
        if (score) {
            const scoreValue = score.querySelector('.score-value');
            scoreValue.textContent = total;
            score.classList.add('score-updated');
            setTimeout(() => score.classList.remove('score-updated'), 500);
        }
    }, rolls.length * 150 + 100);
}

function updatePlayerCurrentScore(username, scoreVal) {
    const scoreEl = document.getElementById(`score-${username}`);
    if (scoreEl) scoreEl.querySelector('.score-value').textContent = scoreVal;
}

function highlightCurrentPlayer(username) {
    document.querySelectorAll('.player-dice-section, .player-item').forEach(el => {
        el.classList.remove('current-turn');
    });
    
    const section = document.getElementById(`player-dice-${username}`);
    if (section) section.classList.add('current-turn');
    
    const player = document.querySelector(`.player-item[data-username="${username}"]`);
    if (player) player.classList.add('current-turn');
}

function highlightWinner(username) {
    document.querySelectorAll('.player-dice-section').forEach(s => s.classList.remove('current-turn'));
    const section = document.getElementById(`player-dice-${username}`);
    if (section) section.classList.add('winner');
}

function updateTurnInfo(currentPlayer) {
    const turnInfo = document.getElementById('current-turn-info');
    const isMyTurn = currentPlayer === currentUsername;
    
    if (isMyTurn && !gameState.hasRolled) {
        turnInfo.innerHTML = `<span class="turn-icon pulse">🎯</span><span class="turn-text"><strong>Ваш ход!</strong> Бросайте кубики!</span>`;
        turnInfo.classList.add('my-turn');
    } else if (gameState.hasRolled) {
        turnInfo.innerHTML = `<span class="turn-icon">✓</span><span class="turn-text">Вы бросили. Ожидание: <strong>${escapeHtml(currentPlayer)}</strong></span>`;
        turnInfo.classList.remove('my-turn');
    } else {
        turnInfo.innerHTML = `<span class="turn-icon">⏳</span><span class="turn-text">Ходит: <strong>${escapeHtml(currentPlayer)}</strong></span>`;
        turnInfo.classList.remove('my-turn');
    }
}

function updateConnectionStatus(connected) {
    const indicator = document.getElementById('connection-indicator');
    if (connected) {
        indicator.classList.remove('disconnected');
        indicator.classList.add('connected');
        indicator.querySelector('.status-text').textContent = 'Подключено';
    } else {
        indicator.classList.remove('connected');
        indicator.classList.add('disconnected');
        indicator.querySelector('.status-text').textContent = 'Отключено';
    }
}

function updatePlayersList(players) {
    const list = document.getElementById('players-list');
    const count = document.getElementById('players-count');
    
    count.textContent = `(${players.length}/4)`;
    
    list.innerHTML = players.map((player, index) => `
        <div class="player-item" data-username="${player.username}">
            <div class="player-rank">#${index + 1}</div>
            <div class="player-avatar-small">${player.username.charAt(0).toUpperCase()}</div>
            <div class="player-info">
                <div class="player-name ${player.username === roomOwner ? 'owner' : ''}">
                    ${escapeHtml(player.username)}${player.username === currentUsername ? ' (Вы)' : ''}
                </div>
                <div class="player-total-score">Всего: <span>${player.total_score || 0}</span></div>
            </div>
            ${player.username === roomOwner ? '<span class="crown">👑</span>' : ''}
        </div>
    `).join('');
}

function updateLeaderboard(players) {
    const list = document.getElementById('leaderboard-list');
    const sorted = [...players].sort((a, b) => (b.total_score || 0) - (a.total_score || 0));
    
    list.innerHTML = sorted.map((player, index) => {
        const medals = ['🥇', '🥈', '🥉'];
        return `
            <div class="leaderboard-item ${player.username === currentUsername ? 'is-me' : ''}">
                <span class="leaderboard-medal">${medals[index] || (index + 1) + '.'}</span>
                <span class="leaderboard-name">${escapeHtml(player.username)}</span>
                <span class="leaderboard-score">${player.total_score || 0}</span>
            </div>
        `;
    }).join('');
}

function showRoundResults(data) {
    const resultsDiv = document.getElementById('round-results');
    document.getElementById('winner-name').textContent = data.winner;
    document.getElementById('winner-score').textContent = `${data.winner_score} очков`;
    
    const sorted = Object.entries(data.all_results).sort((a, b) => b[1].total - a[1].total);
    
    document.getElementById('all-results-grid').innerHTML = sorted.map(([username, result], index) => `
        <div class="result-card ${username === data.winner ? 'winner' : ''} ${username === currentUsername ? 'is-me' : ''}">
            <div class="result-rank">${index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '#' + (index + 1)}</div>
            <div class="result-player">${escapeHtml(username)}${username === currentUsername ? ' (Вы)' : ''}</div>
            <div class="result-rolls-display">${result.rolls.map(r => `<span class="mini-dice">${r}</span>`).join('')}</div>
            <div class="result-total-score">${result.total}</div>
        </div>
    `).join('');
    
    resultsDiv.classList.add('active');
    if (isOwner) document.getElementById('next-round-btn').style.display = 'inline-block';
}

function addRoundToHistory(data) {
    const list = document.getElementById('rounds-history-list');
    const sorted = Object.entries(data.all_results).sort((a, b) => b[1].total - a[1].total);
    
    const item = document.createElement('div');
    item.className = 'round-history-item';
    item.innerHTML = `
        <div class="history-round-header">
            <span class="history-round-number">Раунд ${data.round}</span>
            <span class="history-round-winner">🏆 ${data.winner}</span>
        </div>
        <div class="history-round-results">${sorted.map(([name, r]) => `${escapeHtml(name)}: ${r.total}`).join(' | ')}</div>
    `;
    
    list.insertBefore(item, list.firstChild);
    while (list.children.length > 10) list.removeChild(list.lastChild);
}

function updateGameSettingsUI(state) {
    if (state.dice_type) {
        gameState.diceType = state.dice_type;
        
        // Проверяем, кастомный ли это кубик
        const isCustom = !['d4', 'd6', 'd10', 'd20', 'd100'].includes(state.dice_type);
        
        document.querySelectorAll('#room-dice-selector .dice-option').forEach(btn => {
            btn.classList.remove('active');
            if (isCustom && btn.dataset.value === 'custom') {
                btn.classList.add('active');
            } else if (btn.dataset.value === state.dice_type) {
                btn.classList.add('active');
            }
        });
        
        const customContainer = document.getElementById('custom-dice-container');
        if (isCustom) {
            customContainer.style.display = 'block';
            gameState.isCustomDice = true;
            const value = parseInt(state.dice_type.replace('d', ''));
            document.getElementById('custom-dice-value').value = value;
            gameState.customDiceValue = value;
        } else {
            customContainer.style.display = 'none';
            gameState.isCustomDice = false;
        }
        
        document.getElementById('game-dice-type').value = state.dice_type;
    }
    if (state.dice_count) {
        gameState.diceCount = state.dice_count;
        document.getElementById('game-dice-count').value = state.dice_count;
        document.getElementById('dice-count-value').textContent = state.dice_count;
    }
}

// ===== ЧАТ =====
function initializeChat() {
    const input = document.getElementById('room-chat-input');
    const btn = document.getElementById('send-room-msg');
    
    btn.addEventListener('click', sendMessage);
    input.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendMessage(); });
}

function sendMessage() {
    const input = document.getElementById('room-chat-input');
    const text = input.value.trim();
    if (text) {
        socket.emit('room_chat_message', { room_code: roomCode, username: currentUsername, text });
        input.value = '';
    }
}

function addChatMessage(message) {
    const container = document.getElementById('room-chat-messages');
    const div = document.createElement('div');
    div.className = `chat-message ${message.username === currentUsername ? 'my-message' : ''}`;
    div.innerHTML = `
        <span class="username">${escapeHtml(message.username)}</span>
        <span class="timestamp">${message.timestamp}</span>
        <div class="text">${escapeHtml(message.text)}</div>
    `;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function addSystemMessage(text) {
    const container = document.getElementById('room-chat-messages');
    const div = document.createElement('div');
    div.className = 'chat-message system-message';
    div.innerHTML = `<div class="text">${text}</div>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

function showNotification(message, type = 'info') {
    document.querySelectorAll('.notification').forEach(n => n.remove());
    
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `<span class="notification-icon">${icons[type]}</span><span class="notification-text">${message}</span>`;
    
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

window.addEventListener('beforeunload', () => {
    socket.emit('leave_room', { room_code: roomCode, username: currentUsername });
});

// ===== ЗВУКОВАЯ СИСТЕМА =====
class SoundManager {
    constructor() {
        this.audioContext = null;
        this.enabled = true;
        this.volume = 0.3;
    }
    
    init() {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
    }
    
    playClick() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(800, this.audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(600, this.audioContext.currentTime + 0.05);
        
        gainNode.gain.setValueAtTime(this.volume * 0.3, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.05);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.05);
    }
    
    playRollStart() {
        if (!this.enabled) return;
        this.init();
        
        const duration = 0.15;
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'triangle';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime);
        oscillator.frequency.linearRampToValueAtTime(100, this.audioContext.currentTime + duration);
        
        gainNode.gain.setValueAtTime(this.volume * 0.2, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + duration);
    }
    
    playDiceLand() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(300, this.audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(150, this.audioContext.currentTime + 0.1);
        
        gainNode.gain.setValueAtTime(this.volume * 0.4, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.1);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.1);
    }
    
    playSuccess() {
        if (!this.enabled) return;
        this.init();
        
        const notes = [523.25, 659.25, 783.99];
        
        notes.forEach((freq, i) => {
            setTimeout(() => {
                const oscillator = this.audioContext.createOscillator();
                const gainNode = this.audioContext.createGain();
                
                oscillator.type = 'sine';
                oscillator.connect(gainNode);
                gainNode.connect(this.audioContext.destination);
                
                oscillator.frequency.setValueAtTime(freq, this.audioContext.currentTime);
                
                gainNode.gain.setValueAtTime(this.volume * 0.3, this.audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.2);
                
                oscillator.start(this.audioContext.currentTime);
                oscillator.stop(this.audioContext.currentTime + 0.2);
            }, i * 100);
        });
    }
    
        // Звук hover
    playHover() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(1200, this.audioContext.currentTime);
        
        gainNode.gain.setValueAtTime(this.volume * 0.1, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.03);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.03);
    }x

    playWin() {
        if (!this.enabled) return;
        this.init();
        
        const notes = [523.25, 659.25, 783.99, 1046.5];
        
        notes.forEach((freq, i) => {
            setTimeout(() => {
                const oscillator = this.audioContext.createOscillator();
                const gainNode = this.audioContext.createGain();
                
                oscillator.type = 'sine';
                oscillator.connect(gainNode);
                gainNode.connect(this.audioContext.destination);
                
                oscillator.frequency.setValueAtTime(freq, this.audioContext.currentTime);
                
                gainNode.gain.setValueAtTime(this.volume * 0.4, this.audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.3);
                
                oscillator.start(this.audioContext.currentTime);
                oscillator.stop(this.audioContext.currentTime + 0.3);
            }, i * 150);
        });
    }
    
    playTick() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(1000, this.audioContext.currentTime);
        
        gainNode.gain.setValueAtTime(this.volume * 0.15, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.05);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.05);
    }
    
    playWarning() {
        if (!this.enabled) return;
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.type = 'square';
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.frequency.setValueAtTime(400, this.audioContext.currentTime);
        
        gainNode.gain.setValueAtTime(this.volume * 0.2, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.1);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.1);
    }
}

const soundManager = new SoundManager();