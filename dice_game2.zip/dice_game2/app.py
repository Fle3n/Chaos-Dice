from flask import Flask, render_template, request, session, redirect, url_for, jsonify
from flask_socketio import SocketIO, emit, join_room, leave_room
import random
import string
from datetime import datetime
import secrets
import threading
import time
import sqlite3
import hashlib
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(16)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

DATABASE = 'dice_game.db'

global_chat_messages = []
game_rooms = {}
connected_users = {}
room_timers = {}

def get_db():
    """Получение соединения с базой данных"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Инициализация базы данных"""
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            games_played INTEGER DEFAULT 0,
            games_won INTEGER DEFAULT 0,
            total_score INTEGER DEFAULT 0
        )
    ''')
    
    conn.commit()
    conn.close()
    print("База данных инициализирована")

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def create_user(username, password):
    conn = get_db()
    cursor = conn.cursor()
    
    try:
        password_hash = hash_password(password)
        cursor.execute(
            'INSERT INTO users (username, password_hash) VALUES (?, ?)',
            (username, password_hash)
        )
        conn.commit()
        return True, "Регистрация успешна"
    except sqlite3.IntegrityError:
        return False, "Пользователь с таким именем уже существует"
    finally:
        conn.close()

def verify_user(username, password):
    conn = get_db()
    cursor = conn.cursor()
    
    password_hash = hash_password(password)
    cursor.execute(
        'SELECT * FROM users WHERE username = ? AND password_hash = ?',
        (username, password_hash)
    )
    user = cursor.fetchone()
    conn.close()
    
    if user:
        return True, dict(user)
    return False, None

def get_user_by_username(username):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    conn.close()
    return dict(user) if user else None

def update_user_stats(username, won=False, score=0):
    conn = get_db()
    cursor = conn.cursor()
    
    if won:
        cursor.execute('''
            UPDATE users 
            SET games_played = games_played + 1, 
                games_won = games_won + 1,
                total_score = total_score + ?
            WHERE username = ?
        ''', (score, username))
    else:
        cursor.execute('''
            UPDATE users 
            SET games_played = games_played + 1,
                total_score = total_score + ?
            WHERE username = ?
        ''', (score, username))
    
    conn.commit()
    conn.close()

def username_exists(username):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT id FROM users WHERE username = ?', (username,))
    exists = cursor.fetchone() is not None
    conn.close()
    return exists

init_db()

def generate_room_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

def roll_dice(dice_type, count=1):
    if dice_type == 'd4':
        max_val = 4
    elif dice_type == 'd6':
        max_val = 6
    elif dice_type == 'd10':
        max_val = 10
    elif dice_type == 'd20':
        max_val = 20
    elif dice_type == 'd100':
        max_val = 100
    else:
        try:
            max_val = int(dice_type.replace('d', ''))
            max_val = min(max(max_val, 2), 1000)
        except:
            max_val = 6
    
    rolls = [random.randint(1, max_val) for _ in range(count)]
    return rolls, sum(rolls)

def cancel_room_timer(room_code):
    if room_code in room_timers:
        room_timers[room_code]['cancelled'] = True

def is_logged_in():
    return 'user_id' in session and 'username' in session

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not is_logged_in():
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def process_player_roll(room_code, username, is_auto=False):
    if room_code not in game_rooms:
        return False
    
    room = game_rooms[room_code]
    game_state = room['game_state']
    
    if not game_state['is_rolling']:
        return False
    
    if username in game_state['rolls']:
        return False
    
    if game_state['current_turn'] >= len(room['players']):
        return False
    
    current_player = room['players'][game_state['current_turn']]['username']
    if current_player != username:
        return False
    
    cancel_room_timer(room_code)
    
    rolls, total = roll_dice(game_state['dice_type'], game_state['dice_count'])
    game_state['rolls'][username] = {'rolls': rolls, 'total': total}
    
    for player in room['players']:
        if player['username'] == username:
            player['score'] = total
            player['total_score'] += total
            break
    
    if is_auto:
        socketio.emit('auto_roll_executed', {
            'username': username,
            'rolls': rolls,
            'total': total
        }, room=room_code)
    
    socketio.emit('roll_result', {
        'username': username,
        'rolls': rolls,
        'total': total
    }, room=room_code)
    
    game_state['current_turn'] += 1
    
    if game_state['current_turn'] >= len(room['players']):
        winner = max(game_state['rolls'].items(), key=lambda x: x[1]['total'])
        game_state['is_rolling'] = False
        
        for player in room['players']:
            is_winner = player['username'] == winner[0]
            player_score = game_state['rolls'].get(player['username'], {}).get('total', 0)
            update_user_stats(player['username'], won=is_winner, score=player_score)
        
        socketio.emit('round_finished', {
            'winner': winner[0],
            'winner_score': winner[1]['total'],
            'all_results': game_state['rolls'],
            'players': room['players'],
            'round': game_state['round']
        }, room=room_code)
    else:
        next_player = room['players'][game_state['current_turn']]['username']
        socketio.emit('next_turn', {
            'current_player': next_player,
            'timer_seconds': 7
        }, room=room_code)
        
        start_auto_roll_timer(room_code, next_player, 7)
    
    return True

def start_auto_roll_timer(room_code, username, timeout=7):
    cancel_room_timer(room_code)
    
    timer_id = time.time()
    room_timers[room_code] = {
        'id': timer_id, 
        'cancelled': False,
        'username': username
    }
    
    def do_auto_roll():
        for i in range(timeout * 10):
            time.sleep(0.1)
            if room_code not in room_timers:
                return
            if room_timers[room_code]['id'] != timer_id:
                return
            if room_timers[room_code].get('cancelled'):
                return
        
        if room_code not in room_timers or room_timers[room_code]['id'] != timer_id:
            return
        if room_timers[room_code].get('cancelled') or room_code not in game_rooms:
            return
        
        room = game_rooms[room_code]
        game_state = room['game_state']
        
        if not game_state['is_rolling'] or username in game_state['rolls']:
            return
        if game_state['current_turn'] >= len(room['players']):
            return
        
        current_player = room['players'][game_state['current_turn']]['username']
        if current_player != username:
            return
        
        process_player_roll(room_code, username, is_auto=True)
    
    thread = threading.Thread(target=do_auto_roll, daemon=True)
    thread.start()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if is_logged_in():
        return redirect(url_for('index'))
    
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '').strip()[:20]
        password = request.form.get('password', '')
        
        if not username or not password:
            error = "Заполните все поля"
        elif len(username) < 2:
            error = "Имя должно быть не менее 2 символов"
        elif len(password) < 4:
            error = "Пароль должен быть не менее 4 символов"
        else:
            success, user = verify_user(username, password)
            if success:
                session['user_id'] = user['id']
                session['username'] = user['username']
                return redirect(url_for('index'))
            else:
                error = "Неверное имя пользователя или пароль"
    
    return render_template('login.html', error=error)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if is_logged_in():
        return redirect(url_for('index'))
    
    error = None
    success = None
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()[:20]
        password = request.form.get('password', '')
        password_confirm = request.form.get('password_confirm', '')
        
        if not username or not password or not password_confirm:
            error = "Заполните все поля"
        elif len(username) < 2:
            error = "Имя должно быть не менее 2 символов"
        elif len(username) > 20:
            error = "Имя должно быть не более 20 символов"
        elif len(password) < 4:
            error = "Пароль должен быть не менее 4 символов"
        elif password != password_confirm:
            error = "Пароли не совпадают"
        elif not username.replace('_', '').replace('-', '').isalnum():
            error = "Имя может содержать только буквы, цифры, _ и -"
        else:
            created, message = create_user(username, password)
            if created:
                success = "Регистрация успешна! Теперь войдите в систему."
            else:
                error = message
    
    return render_template('register.html', error=error, success=success)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/profile')
@login_required
def profile():
    user = get_user_by_username(session['username'])
    return render_template('profile.html', user=user, username=session['username'])

@app.route('/')
@login_required
def index():
    return render_template('index.html', username=session['username'])

@app.route('/developers')
@login_required
def developers():
    return render_template('developers.html', username=session['username'])

@app.route('/room/<room_code>')
@login_required
def room(room_code):
    if room_code not in game_rooms:
        return redirect(url_for('index'))
    
    room_data = game_rooms[room_code]
    
    if room_data['is_private']:
        if session['username'] == room_data['owner']:
            session[f'room_access_{room_code}'] = True
        
        if not session.get(f'room_access_{room_code}'):
            return redirect(url_for('room_password', room_code=room_code))
    
    return render_template('room.html', 
                         room_code=room_code, 
                         room_data=room_data,
                         username=session['username'])

@app.route('/room/<room_code>/password')
@login_required
def room_password(room_code):
    if room_code not in game_rooms:
        return redirect(url_for('index'))
    
    room_data = game_rooms[room_code]
    
    if not room_data['is_private'] or session.get(f'room_access_{room_code}'):
        return redirect(url_for('room', room_code=room_code))
    
    return render_template('room_password.html', 
                         room_code=room_code, 
                         room_name=room_data['name'],
                         username=session['username'])

@app.route('/check_password', methods=['POST'])
@login_required
def check_password():
    data = request.get_json()
    room_code = data.get('room_code')
    password = data.get('password')
    
    if room_code in game_rooms:
        room = game_rooms[room_code]
        if room['password'] == password:
            session[f'room_access_{room_code}'] = True
            return jsonify({'success': True})
        return jsonify({'success': False, 'error': 'Неверный пароль'})
    
    return jsonify({'success': False, 'error': 'Комната не найдена'})

@app.route('/get_rooms')
@login_required
def get_rooms():
    public_rooms = []
    for code, room in game_rooms.items():
        if not room['is_private']:
            public_rooms.append({
                'code': code,
                'name': room['name'][:20],
                'players': len(room['players']),
                'max_players': 4,
                'owner': room['owner']
            })
    return jsonify(public_rooms)

@app.route('/check_username')
def check_username():
    """API для проверки доступности имени"""
    username = request.args.get('username', '').strip()
    if username and len(username) >= 2:
        exists = username_exists(username)
        return jsonify({'available': not exists})
    return jsonify({'available': False})

@socketio.on('connect')
def handle_connect():
    print(f"Клиент подключен: {request.sid}")

@socketio.on('disconnect')
def handle_disconnect():
    sid = request.sid
    for room_code, room_data in list(game_rooms.items()):
        for player in room_data['players'][:]:
            if player.get('sid') == sid:
                room_data['players'].remove(player)
                emit('player_left', {
                    'username': player['username'],
                    'players': room_data['players']
                }, room=room_code)
                
                if len(room_data['players']) == 0:
                    cancel_room_timer(room_code)
                    if room_code in room_timers:
                        del room_timers[room_code]
                    del game_rooms[room_code]
                break
    
    if sid in connected_users:
        del connected_users[sid]

@socketio.on('set_user')
def handle_set_user(data):
    connected_users[request.sid] = data['username']

@socketio.on('global_chat_message')
def handle_global_chat(data):
    message = {
        'username': data['username'][:20],
        'text': data['text'][:200],
        'timestamp': datetime.now().strftime('%H:%M:%S')
    }
    global_chat_messages.append(message)
    
    if len(global_chat_messages) > 100:
        global_chat_messages.pop(0)
    
    emit('new_global_message', message, broadcast=True)

@socketio.on('get_chat_history')
def handle_get_chat_history():
    emit('chat_history', global_chat_messages)

@socketio.on('create_room')
def handle_create_room(data):
    room_code = generate_room_code()
    while room_code in game_rooms:
        room_code = generate_room_code()
    
    username = data['username'][:20]
    room_name = data['name'][:20] if data.get('name') else f'Комната {random.randint(100, 999)}'
    is_private = data.get('is_private', False)
    
    game_rooms[room_code] = {
        'code': room_code,
        'name': room_name,
        'is_private': is_private,
        'password': data.get('password', '') if is_private else '',
        'owner': username,
        'players': [],
        'game_state': {
            'current_turn': 0,
            'dice_type': 'd6',
            'dice_count': 1,
            'rolls': {},
            'is_rolling': False,
            'round': 0
        }
    }
    
    emit('room_created', {
        'room_code': room_code,
        'is_private': is_private
    })

@socketio.on('join_room')
def handle_join_room(data):
    room_code = data['room_code']
    username = data['username'][:20]
    
    if room_code not in game_rooms:
        emit('join_error', {'error': 'Комната не найдена'})
        return
    
    room = game_rooms[room_code]
    
    if len(room['players']) >= 4:
        emit('join_error', {'error': 'Комната заполнена'})
        return
    
    for player in room['players']:
        if player['username'] == username:
            player['sid'] = request.sid
            join_room(room_code)
            emit('joined_room', {
                'room_code': room_code,
                'room_data': room,
                'is_owner': room['owner'] == username
            })
            return
    
    player_data = {
        'username': username,
        'sid': request.sid,
        'score': 0,
        'total_score': 0
    }
    
    room['players'].append(player_data)
    join_room(room_code)
    
    emit('joined_room', {
        'room_code': room_code,
        'room_data': room,
        'is_owner': room['owner'] == username
    })
    
    emit('player_joined', {
        'username': username,
        'players': room['players']
    }, room=room_code)

@socketio.on('leave_room')
def handle_leave_room(data):
    room_code = data['room_code']
    username = data['username']
    
    if room_code in game_rooms:
        room = game_rooms[room_code]
        room['players'] = [p for p in room['players'] if p['username'] != username]
        leave_room(room_code)
        
        emit('player_left', {
            'username': username,
            'players': room['players']
        }, room=room_code)
        
        if len(room['players']) == 0:
            cancel_room_timer(room_code)
            if room_code in room_timers:
                del room_timers[room_code]
            del game_rooms[room_code]
        elif room['owner'] == username and room['players']:
            room['owner'] = room['players'][0]['username']
            emit('new_owner', {'owner': room['owner']}, room=room_code)

@socketio.on('update_game_settings')
def handle_update_settings(data):
    room_code = data['room_code']
    if room_code in game_rooms:
        room = game_rooms[room_code]
        room['game_state']['dice_type'] = data['dice_type']
        room['game_state']['dice_count'] = min(max(data['dice_count'], 1), 5)
        
        emit('settings_updated', {
            'dice_type': data['dice_type'],
            'dice_count': room['game_state']['dice_count']
        }, room=room_code)

@socketio.on('start_roll')
def handle_start_roll(data):
    room_code = data['room_code']
    if room_code not in game_rooms:
        return
    
    room = game_rooms[room_code]
    game_state = room['game_state']
    
    if len(room['players']) < 2:
        emit('roll_error', {'error': 'Нужно минимум 2 игрока'})
        return
    
    game_state['is_rolling'] = True
    game_state['rolls'] = {}
    game_state['current_turn'] = 0
    game_state['round'] += 1
    
    first_player = room['players'][0]['username']
    
    emit('roll_started', {
        'current_player': first_player,
        'dice_type': game_state['dice_type'],
        'dice_count': game_state['dice_count'],
        'round': game_state['round'],
        'timer_seconds': 7
    }, room=room_code)
    
    start_auto_roll_timer(room_code, first_player, 7)

@socketio.on('player_roll')
def handle_player_roll(data):
    room_code = data['room_code']
    username = data['username']
    
    success = process_player_roll(room_code, username, is_auto=False)
    
    if not success:
        emit('roll_error', {'error': 'Не удалось выполнить бросок'})

@socketio.on('room_chat_message')
def handle_room_chat(data):
    room_code = data['room_code']
    message = {
        'username': data['username'][:20],
        'text': data['text'][:200],
        'timestamp': datetime.now().strftime('%H:%M:%S')
    }
    emit('new_room_message', message, room=room_code)

@socketio.on('solo_roll')
def handle_solo_roll(data):
    dice_type = data['dice_type']
    dice_count = min(max(data['dice_count'], 1), 10)
    rolls, total = roll_dice(dice_type, dice_count)
    emit('solo_roll_result', {'rolls': rolls, 'total': total})

@app.route('/leaderboard')
@login_required
def leaderboard():
    """Страница таблицы лидеров"""
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT username, games_won, games_played, total_score,
               CASE WHEN games_played > 0 
                    THEN ROUND(CAST(games_won AS FLOAT) / games_played * 100, 1) 
                    ELSE 0 
               END as winrate
        FROM users 
        WHERE games_played > 0
        ORDER BY games_won DESC 
        LIMIT 10
    ''')
    top_wins = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT username, games_won, games_played, total_score,
               CASE WHEN games_played > 0 
                    THEN ROUND(CAST(games_won AS FLOAT) / games_played * 100, 1) 
                    ELSE 0 
               END as winrate
        FROM users 
        WHERE games_played > 0
        ORDER BY total_score DESC 
        LIMIT 10
    ''')
    top_score = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT username, games_won, games_played, total_score,
               ROUND(CAST(games_won AS FLOAT) / games_played * 100, 1) as winrate
        FROM users 
        WHERE games_played >= 5
        ORDER BY winrate DESC 
        LIMIT 10
    ''')
    top_winrate = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT username, games_won, games_played, total_score,
               CASE WHEN games_played > 0 
                    THEN ROUND(CAST(games_won AS FLOAT) / games_played * 100, 1) 
                    ELSE 0 
               END as winrate
        FROM users 
        WHERE games_played > 0
        ORDER BY games_played DESC 
        LIMIT 10
    ''')
    top_games = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT 
            (SELECT COUNT(*) + 1 FROM users WHERE games_won > u.games_won) as rank_wins,
            (SELECT COUNT(*) + 1 FROM users WHERE total_score > u.total_score) as rank_score,
            (SELECT COUNT(*) + 1 FROM users WHERE games_played > u.games_played) as rank_games,
            u.games_won, u.games_played, u.total_score,
            CASE WHEN u.games_played > 0 
                 THEN ROUND(CAST(u.games_won AS FLOAT) / u.games_played * 100, 1) 
                 ELSE 0 
            END as winrate
        FROM users u
        WHERE u.username = ?
    ''', (session['username'],))
    
    user_stats = cursor.fetchone()
    user_rank = dict(user_stats) if user_stats else None
    
    conn.close()
    
    return render_template('leaderboard.html', 
                         username=session['username'],
                         top_wins=top_wins,
                         top_score=top_score,
                         top_winrate=top_winrate,
                         top_games=top_games,
                         user_rank=user_rank)

if __name__ == '__main__':
    socketio.run(app, debug=True, host='0.0.0.0', port=5001)
    # Если программа не запускается, добавьте в socketio.run параметр allow_unsafe_werkzeug=True